<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario Numeros</title>
   
</head>
<body>

    <div id="contenedorFormulario">
        <form name="frmnumeros" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method ="POST">
            <div>
                <input type="number" name="inputN" id="inputN">
                <select name="selectField[]" id="selectField" size="6" multiple="multiple"></select>
                <input type="reset" name="agregarB" id="agregarB" value="Agregar Numero">
            </div>

            <input type="submit" name="submitB" id="submitB" value="Enviar Numeros">
        </form>
    </div>
    
</body>
<script src="agregar.js"></script>
</html>


<?php

function calcularMayorMenor($selectField){
    if(is_array($selectField)){
        $numeroMax = max($selectField);
        $numeroMin = min($selectField);

        echo "<p>El numero mayor de la lista es: ".$numeroMax.",y el numero menor es: ".$numeroMin." </p>"
    }
}

if(isset($_POST['submitB'])){
    if(isset($_POST['selectedField'])){
        calcularMayorMenor($_POST['selectField']);
    }else{
        $msgerr = "No hay numeros para procesar.";
        $numeros = array($msgerr);
        calcularMayorMenor($numeros);
    }
    
}
?>